const functions = require('firebase-functions');
const firebase = require('firebase-admin');
const express = require('express');
const engines = require('consolidate');
const ejs = require('ejs');
const fs = require('fs');


const app = express();

app.get('/home', (request, response) => {
    response.set('Cache-Control', 'public, max-age=300, s-maxage=600');
    
    response.end('Home page');
});

app.get('/profile', (request, response) => {
    response.set('Cache-Control', 'public, max-age=300, s-maxage=600');
    
    response.end('Profile page');
});

exports.app2 = functions.https.onRequest(app);